-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `problem`
--

DROP TABLE IF EXISTS `problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `problem` (
  `DTYPE` varchar(31) NOT NULL,
  `problem_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `is_removed` bit(1) DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`problem_id`),
  KEY `FK5qlt94mi6xg5vaqg4hwso1fj6` (`category_id`),
  CONSTRAINT `FK5qlt94mi6xg5vaqg4hwso1fj6` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem`
--

LOCK TABLES `problem` WRITE;
/*!40000 ALTER TABLE `problem` DISABLE KEYS */;
INSERT INTO `problem` VALUES ('name_problem',32,NULL,_binary '\0',1),('name_problem',33,NULL,_binary '\0',1),('name_problem',34,NULL,_binary '\0',1),('name_problem',35,NULL,_binary '\0',1),('name_problem',36,NULL,_binary '\0',1),('name_problem',37,NULL,_binary '\0',1),('name_problem',38,NULL,_binary '\0',1),('name_problem',39,NULL,_binary '\0',1),('name_problem',40,NULL,_binary '\0',1),('name_problem',41,NULL,_binary '\0',1),('name_problem',42,NULL,_binary '\0',1),('name_problem',43,NULL,_binary '\0',1),('name_problem',44,NULL,_binary '\0',1),('name_problem',45,NULL,_binary '\0',1),('name_problem',46,NULL,_binary '\0',1),('name_problem',47,NULL,_binary '\0',2),('name_problem',48,NULL,_binary '\0',2),('name_problem',49,NULL,_binary '\0',2),('name_problem',50,NULL,_binary '\0',2),('name_problem',51,NULL,_binary '\0',2),('name_problem',52,NULL,_binary '\0',2),('name_problem',53,NULL,_binary '\0',2),('name_problem',54,NULL,_binary '\0',2),('name_problem',55,NULL,_binary '\0',2),('name_problem',56,NULL,_binary '\0',2),('name_problem',57,NULL,_binary '\0',2),('name_problem',58,NULL,_binary '\0',2),('name_problem',59,NULL,_binary '\0',2),('name_problem',60,NULL,_binary '\0',2),('name_problem',61,NULL,_binary '\0',2),('name_problem',62,NULL,_binary '\0',3),('name_problem',63,NULL,_binary '\0',3),('name_problem',64,NULL,_binary '\0',3),('name_problem',65,NULL,_binary '\0',3),('name_problem',66,NULL,_binary '\0',3),('name_problem',67,NULL,_binary '\0',3),('name_problem',68,NULL,_binary '\0',3),('name_problem',69,NULL,_binary '\0',3),('name_problem',70,NULL,_binary '\0',3),('name_problem',71,NULL,_binary '\0',3),('name_problem',72,NULL,_binary '\0',3),('name_problem',73,NULL,_binary '\0',3),('name_problem',74,NULL,_binary '\0',3),('name_problem',75,NULL,_binary '\0',3),('name_problem',76,NULL,_binary '\0',3),('text_matching_problem',81,NULL,_binary '\0',7),('text_matching_problem',82,NULL,_binary '\0',7),('text_matching_problem',83,NULL,_binary '\0',7),('text_matching_problem',84,NULL,_binary '\0',7),('text_matching_problem',85,NULL,_binary '\0',7),('text_matching_problem',86,NULL,_binary '\0',7),('text_matching_problem',87,NULL,_binary '\0',7),('text_matching_problem',88,NULL,_binary '\0',7),('text_matching_problem',89,NULL,_binary '\0',7),('text_matching_problem',90,NULL,_binary '\0',7),('text_matching_problem',91,NULL,_binary '\0',7),('text_matching_problem',92,NULL,_binary '\0',7),('text_matching_problem',93,NULL,_binary '\0',7),('text_matching_problem',94,NULL,_binary '\0',7),('text_matching_problem',95,NULL,_binary '\0',7),('speaking_problem',96,NULL,_binary '\0',4),('speaking_problem',97,NULL,_binary '\0',4),('speaking_problem',98,NULL,_binary '\0',4),('speaking_problem',99,NULL,_binary '\0',4),('speaking_problem',100,NULL,_binary '\0',4),('speaking_problem',101,NULL,_binary '\0',4),('speaking_problem',102,NULL,_binary '\0',4),('speaking_problem',103,NULL,_binary '\0',4),('speaking_problem',104,NULL,_binary '\0',4),('speaking_problem',105,NULL,_binary '\0',4),('speaking_problem',106,NULL,_binary '\0',4),('speaking_problem',107,NULL,_binary '\0',4),('speaking_problem',108,NULL,_binary '\0',4),('speaking_problem',109,NULL,_binary '\0',4),('speaking_problem',110,NULL,_binary '\0',4),('speaking_problem',111,NULL,_binary '\0',5),('speaking_problem',112,NULL,_binary '\0',5),('speaking_problem',113,NULL,_binary '\0',5),('speaking_problem',114,NULL,_binary '\0',5),('speaking_problem',115,NULL,_binary '\0',5),('speaking_problem',116,NULL,_binary '\0',5),('speaking_problem',117,NULL,_binary '\0',5),('speaking_problem',118,NULL,_binary '\0',5),('speaking_problem',119,NULL,_binary '\0',5),('speaking_problem',120,NULL,_binary '\0',5),('speaking_problem',121,NULL,_binary '\0',5),('speaking_problem',122,NULL,_binary '\0',5),('speaking_problem',123,NULL,_binary '\0',5),('speaking_problem',124,NULL,_binary '\0',5),('speaking_problem',125,NULL,_binary '\0',5),('speaking_problem',126,NULL,_binary '\0',5),('image_matching_problem',127,NULL,_binary '\0',6),('image_matching_problem',128,NULL,_binary '\0',6),('image_matching_problem',129,NULL,_binary '\0',6),('image_matching_problem',130,NULL,_binary '\0',6),('image_matching_problem',131,NULL,_binary '\0',6),('image_matching_problem',132,NULL,_binary '\0',6),('image_matching_problem',134,NULL,_binary '\0',6),('image_matching_problem',135,NULL,_binary '\0',6),('image_matching_problem',136,NULL,_binary '\0',6),('image_matching_problem',137,NULL,_binary '\0',6),('fluency_problem',138,NULL,_binary '\0',8),('fluency_problem',139,NULL,_binary '\0',8),('fluency_problem',140,NULL,_binary '\0',8),('fluency_problem',141,NULL,_binary '\0',8),('fluency_problem',142,NULL,_binary '\0',8),('fluency_problem',143,NULL,_binary '\0',8),('fluency_problem',144,NULL,_binary '\0',8),('fluency_problem',145,NULL,_binary '\0',8),('fluency_problem',146,NULL,_binary '\0',8),('fluency_problem',147,NULL,_binary '\0',8),('fluency_problem',148,NULL,_binary '\0',8),('fluency_problem',149,NULL,_binary '\0',8),('fluency_problem',150,NULL,_binary '\0',8),('fluency_problem',151,NULL,_binary '\0',8),('fluency_problem',152,NULL,_binary '\0',8);
/*!40000 ALTER TABLE `problem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:09

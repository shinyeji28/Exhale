-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `name_problem`
--

DROP TABLE IF EXISTS `name_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_problem` (
  `answer` varchar(255) DEFAULT NULL,
  `hint` varchar(255) DEFAULT NULL,
  `question_image` varchar(255) DEFAULT NULL,
  `problem_id` bigint NOT NULL,
  PRIMARY KEY (`problem_id`),
  CONSTRAINT `FKooukp83o87h63faptmxx981wq` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_problem`
--

LOCK TABLES `name_problem` WRITE;
/*!40000 ALTER TABLE `name_problem` DISABLE KEYS */;
INSERT INTO `name_problem` VALUES ('청소하다','ㅊㅅ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/cleaning.jpg',32),('화내다','ㅎ내다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/angry.jpg',33),('쓰다듬다','ㅆㄷ듬다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/cat.jpg',34),('뜨개질하다','ㄸㄱ질하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/crochet.jpg',35),('팔씨름하다','ㅍㅆㄹ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/french-foreign-legion.jpg',36),('게임하다','ㄱㅇ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/game.jpg',37),('숟가락질하다','ㅅㄱㄹ질하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/people.jpg',38),('책읽다','ㅊ읽다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/read.jpg',39),('삽질하다','ㅅ질하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/shoveling.jpg',40),('자다','ㅈ다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/sleep.jpg',41),('웃다','ㅇ다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/smail.jpg',42),('자전거타다','ㅈㅈㄱ타다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/snow.jpg',43),('색칠하다','ㅅㅊ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/to-paint.jpg',44),('요가하다','ㅇㄱ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/woman.jpg',45),('하품하다','ㅎㅍ하다','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/behavior/yawn.jpg',46),('망원경','ㅁㅇㄱ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/binoculars.jpg',47),('고양이','ㄱㅇㅇ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/cat.jpg',48),('시계','ㅅㄱ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/clock.jpg',49),('옥수수','ㅇㅅㅅ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/corn-3705687_1920.jpg',50),('기린','ㄱㄹ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/giraffes.jpg',51),('컴퓨터','ㅋㅍㅌ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/laptop.jpg',52),('기차','ㄱㅊ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/metro.jpg',53),('원숭이','ㅇㅅㅇ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/monkey.jpg',54),('파인애플','ㅍㅇㅇㅍ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/pineapple.jpg',55),('리모컨','ㄹㅁㅋ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/remote-controller-1863437_1920.jpg',56),('바다','ㅂㄷ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/sea.jpg',57),('신발','ㅅㅂ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/shoes.jpg',58),('양말','ㅇㅁ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/socks.jpg',59),('비행기','ㅂㅎㄱ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/transport.jpg',60),('우산','ㅇㅅ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/objects/umbrella.jpg',61),('공항','ㄱㅎ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/airport.jpg',62),('화장실','ㅎㅈㅅ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/bathroom.jpg',63),('캠핑장','ㅋㅍㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/besides-the-cancer-time-to-nearby-lodging.jpg',64),('교회','ㄱㅎ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/catholic-church.png',65),('학교','ㅎㄱ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/classroom.jpg',66),('사막','ㅅㅁ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/desert.jpg',67),('골프장','ㄱㅍㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/golf.jpg',68),('병원','ㅂㅇ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/hospital.jpg',69),('부엌','ㅂㅇ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/kitchen.jpg',70),('서점','ㅅㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/library.jpg',71),('도서관','ㄷㅅㄱ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/library1.jpg',72),('시장','ㅅㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/market.jpg',73),('놀이공원','ㄴㅇㄱㅇ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/merry-go-round.jpg',74),('수영장','ㅅㅇㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/pool.jpg',75),('스키장','ㅅㅋㅈ','https://nalsum1.s3.ap-northeast-2.amazonaws.com/name-problem/place/ski-slope.jpg',76);
/*!40000 ALTER TABLE `name_problem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:07

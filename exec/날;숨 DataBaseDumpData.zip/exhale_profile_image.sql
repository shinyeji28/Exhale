-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_image`
--

DROP TABLE IF EXISTS `profile_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_image` (
  `profile_image_id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  PRIMARY KEY (`profile_image_id`),
  UNIQUE KEY `UK_j6qn0q2dwkiau4mbkwb2hmcld` (`member_id`),
  CONSTRAINT `FK6mi6j2vxbqt4sedv8kl3hgtlu` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_image`
--

LOCK TABLES `profile_image` WRITE;
/*!40000 ALTER TABLE `profile_image` DISABLE KEYS */;
INSERT INTO `profile_image` VALUES (5,'2024-02-09 08:57:41.980162','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',5),(6,'2024-02-11 11:29:45.952911','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',6),(7,'2024-02-11 11:59:46.577309','https://nalsum1.s3.amazonaws.com/b88f1206-b322-496c-8a8b-0bf1ff894a96.jpg',7),(8,'2024-02-11 15:25:51.731097','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',8),(9,'2024-02-12 13:56:15.307475','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',9),(10,'2024-02-13 01:13:49.096142','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',10),(11,'2024-02-13 06:47:19.152429','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',11),(12,'2024-02-14 06:39:03.168234','https://nalsum1.s3.amazonaws.com/0d39919f-8de5-46b1-bf0a-307fe8dc9aff.com',12),(13,'2024-02-15 06:21:01.920171','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',13),(14,'2024-02-15 08:39:10.617375','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',14),(15,'2024-02-15 17:18:15.805321','https://nalsum1.s3.ap-northeast-2.amazonaws.com/default/profile_image1.png',15);
/*!40000 ALTER TABLE `profile_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:07

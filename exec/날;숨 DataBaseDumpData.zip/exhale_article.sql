-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `article_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT '0',
  `modify_time` datetime(6) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `view` int NOT NULL,
  `board_id` int DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  KEY `FK2y7w132xb5xp1aiouig87aqjo` (`board_id`),
  KEY `FK6l9vkfd5ixw8o8kph5rj1k7gu` (`member_id`),
  CONSTRAINT `FK2y7w132xb5xp1aiouig87aqjo` FOREIGN KEY (`board_id`) REFERENCES `board` (`board_id`),
  CONSTRAINT `FK6l9vkfd5ixw8o8kph5rj1k7gu` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (107,'계속 꾸준히 연습하다 보니 말이 나오고 있어요. 하루에 한 시간씩 언어 재활 치료를 받고 있고 날숨을 통해서도 연습 하고 있습니다.  앞으로 연습 계속 하겠습니다!','2024-02-15 11:46:08.101049',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/c5f0cfc3-185b-436d-aa6c-7fbb57a8f70d.jpg','조금씩 나아지는 것 같네요.',2,3,9),(108,'실어증은 언어 이해나 사용에 장애를 초래하는 신경학적인 장애로, 일상 소통에 어려움을 겪게 합니다. 이는 뇌의 특정 부분의 손상이나 기능 이상으로 인해 발생할 수 있으며, 음성 치료와 언어 재교육을 통해 관리할 수 있습니다.','2024-02-15 11:47:24.535420',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/96070006-b9d8-46e4-b06b-a8c825178838.jpg','실어증이란?',3,1,9),(110,'오늘은 친구들과 함께 즐거운 시간을 보냈습니다. 함께 놀이공원을 다녀오며 즐거운 추억을 만들었고, 웃음 속에 스트레스를 잊을 수 있었습니다. 맛있는 음식도 함께 즐기며 행복한 하루를 보낸 후, 각자의 길을 걸어 행복한 기억을 안고 집으로 갔습니다. 재밌었습니다.','2024-02-15 11:53:01.220889',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/14a67b44-ea33-4c5f-9812-7ac5be5c18b8.jpg','오늘 놀이공원 다녀왔어요.',2,3,9),(111,'실어증 환자 소모임에 다녀왔습니다. 소모임에서 회원분들과 함께 실어증 치료를 위한 노력을 공유하고 서로를 다독여 주는 시간을 가졌습니다.?\n\n특히 지난달까지 너무 힘들어했던 정XX 회원분께서 증상이 많이 호전되신 상태로 나타나셨습니다!! 개인의 노력으로 이정도까지 실어증이 회복될 수 있다는 사실이 모임에 있는 모두에게 희망이 되었습니다 :)','2024-02-15 11:55:49.028242',0,NULL,'희중','https://nalsum1.s3.amazonaws.com/dea14821-8af9-4789-95a4-57604687bddd.jpg','실어증 환자 소모임 후기',14,3,12),(113,'집에 홀로 있으면서, 실어증 재활 치료를 하고자 방법을 찾다가 날숨이라는 서비스를 알게되었습니다. 날숨을 통해 혼자서 재활 서비스를 제공받으며 나름 호전되고 있다는 기분과 재활에 대한 의지를 찾을 수 있었습니다. 저와 같은 실어증 친구분들도 집에서 혼자 날숨과 함께 혼자서도 발화 연습을 해보는건 어떨까요?','2024-02-15 12:01:06.568039',0,NULL,'희중','https://nalsum1.s3.amazonaws.com/69a11405-3f46-45eb-b6c8-b72c77cab3ec.PNG','날;숨과 함께한 재활의 노력',1,2,12),(114,'치료를 받은 후에는 의사소통이 원활해졌고, 일상 생활에서 능동적으로 참여할 수 있게 되었습니다. 음성 치료와 언어 재교육 프로그램은 큰 도움이 되었고, 자신감을 되찾을 수 있었습니다. 이제는 증상에 대한 이해도가 높아져 더 이해받을 수 있게 되었습니다. 치료 후의 변화는 저에게 큰 희망을 안겨주었습니다.','2024-02-15 12:01:31.912227',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/cd542546-d9b8-4602-a00b-1aab5a52ed48.jpg','실어증 한 달 치료 후기',4,2,9),(115,'실어증의 원인은 주로 뇌 손상이나 기능 이상으로 인해 발생합니다. 뇌졸중, 외상성 뇌손상, 뇌종양, 뇌염 등이 원인이 될 수 있습니다. 또한 노화나 질병으로 인한 뇌의 변화도 실어증을 유발할 수 있습니다. 어린이의 경우 선천적인 신경학적 문제나 발달 지연이 원인이 될 수 있습니다. 유전적인 요인도 가능성이 있습니다.','2024-02-15 12:03:09.353199',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/8afcdf19-030b-43de-ac53-d9c1754f866b.jpg','실어증의 원인',4,3,9),(116,'실어증 모임에서는 서로의 경험을 나누고 지원을 받는 것이 주된 목적입니다. 모임은 일상에서 겪는 어려움을 공유하고 해결책을 찾는 공간으로 활용됩니다. 멤버들은 치료나 훈련에 대한 정보를 교환하고, 서로의 성공 이야기를 들으며 격려를 받습니다. 모임은 실어증 환자들에게 사회적 지원과 함께 심리적인 안정감을 제공합니다. 그들은 모임을 통해 서로에게 희망과 동기부여를 얻을 수 있습니다.','2024-02-15 12:05:20.219596',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/11f45f83-d77b-4477-8e1c-b5b4bf36084e.jpg','실어증 모임의 효용성',3,1,9),(117,'오늘 말이 유창하게 나오는 것 같네요. 커뮤니티를 보면서 많은 공감과 희망을 느끼는 것 같아요. 다들 화이팅!','2024-02-15 12:07:58.741823',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/33827020-6c56-4368-a9c5-a72fc834fc10.jpg','오늘, 다들 어떠셨나요?',8,3,9),(118,'100문제 풀었습니다. 처음엔 힘들었는데 꾸준히 풀다보니 많이 늘었습니다!..','2024-02-15 12:11:31.325832',0,NULL,'건준','https://nalsum1.s3.amazonaws.com/441b7ec1-1099-4d17-9bbb-f6ade027b17b.jpg','날숨에서 100문제 풀었습니다.',11,3,9),(119,'지난달 사고로 인해 머리를 다친 후, 사람들과 대화하는게 전보다 어렵다는 느낌이 들기 시작했습니다. 가족들도 제가 사람들과 대화하는데 어려움을 느낀다고 말하며 실어증 검사를 받아보라고 제안했습니다. 실어증 검사를 받으로 대전 언어치료센터에 방문했습니다. 검사를파라다이스 웨스턴 실어증 검사를통해 검사한 결과 다행히 실어증 초기 단계로, 시간이 경과하면서 점차 나아 질 수 있다고 의사선생님께서 말씀하셨습니다.','2024-02-15 12:17:02.297020',1,'2024-02-15 12:17:54.520039','희중',NULL,'실어증검사를 받고왔습니다',10,2,12),(120,'지난달 사고로 인해 머리를 다친 후, 사람들과 대화하는게 전보다 어렵다는 느낌이 들기 시작했습니다. 가족들도 제가 사람들과 대화하는데 어려움을 느낀다고 말하며 실어증 검사를 받아보라고 제안했습니다. 실어증 검사를 받으로 대전 언어치료센터에 방문했습니다. 검사를파라다이스 웨스턴 실어증 검사를통해 검사한 결과 다행히 실어증 초기 단계로, 시간이 경과하면서 점차 나아 질 수 있다고 의사선생님께서 말씀하셨습니다.','2024-02-15 12:18:40.820384',0,NULL,'희중','https://nalsum1.s3.amazonaws.com/f2603ba2-d33d-4fad-a10c-d1eb4100fcb7.png','실어증검사를 받고왔습니다',15,2,12),(121,'실어증의 원인은 다양하며, 주로 대뇌의 특정 부분의 손상으로 인해 발생합니다.\n뇌졸중 (Stroke): 뇌졸중으로 인해 뇌의 특정 부분이 손상되어 실어증이 발생할 수 있습니다.\n외상성 뇌손상 (Traumatic Brain Injury): 사고나 충격 등으로 뇌가 손상되는 경우도 실어증의 원인이 될 수 있습니다\n신경퇴행성 질환 (Neurodegenerative Diseases): 신경퇴행성 질환은 뇌 조직의 손상으로 인해 실어증을 유발할 수 있습니다.','2024-02-15 12:27:02.971673',0,NULL,'희중','https://nalsum1.s3.amazonaws.com/6d5efb79-cea8-4cfa-98f0-282f1b84fe0d.png','실어증의 원인과 종류 (1)',22,1,12),(122,'사람들과 어떤 방식으로 말하기 연습을 하시는지 궁금합니다','2024-02-15 12:28:41.758912',0,NULL,'희중','https://nalsum1.s3.amazonaws.com/89aa1378-5e25-4ce2-b228-20fb6d1d7c46.jpg','다들 주로 어떤 방식으로 말하기 연습하시나요?',18,3,12),(123,'다들 힘들 때입니다만, 모두 힘내서 회복하셨으면 좋겠습니다. 우리 모두 화이팅!','2024-02-15 12:51:04.212454',1,'2024-02-15 12:51:29.831020','하이테이블',NULL,'모두들 힘냅시다',6,3,8),(124,'다들 힘들 때입니다만, 모두 힘내서 회복하셨으면 좋겠습니다. 우리 모두 화이팅!','2024-02-15 12:52:02.550721',0,NULL,'하이테이블','https://nalsum1.s3.amazonaws.com/7ac7aa26-82fe-4ebc-a1a4-e52d51247c02.png','다들 힘냅시다.',53,3,8);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:09

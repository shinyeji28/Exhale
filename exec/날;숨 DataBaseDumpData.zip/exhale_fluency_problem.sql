-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fluency_problem`
--

DROP TABLE IF EXISTS `fluency_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fluency_problem` (
  `question` varchar(255) DEFAULT NULL,
  `problem_id` bigint NOT NULL,
  PRIMARY KEY (`problem_id`),
  CONSTRAINT `FKcqoaowa62ke0uybvedns8s0a9` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fluency_problem`
--

LOCK TABLES `fluency_problem` WRITE;
/*!40000 ALTER TABLE `fluency_problem` DISABLE KEYS */;
INSERT INTO `fluency_problem` VALUES ('내일 영화 보러 갈래?',138),('어제 뭐했어?',139),('오늘 날씨 어때요?',140),('오늘은 무엇을 할 계획인가요?',141),('새로운 요리를 시도해보신 적이 있나요? 있다면 어떤 요리였나요?',142),('가장 좋아하는 계절은 무엇인가요?',143),('주말에는 보통 어떻게 시간을 보내시나요?',144),('취미가 무엇인가요?',145),('요즘에는 어떤 음악을 자주 듣고 계신가요?',146),('오늘은 하루를 어떻게 마무리하실 건가요?',147),('가장 기억에 남는 여행 경험은 무엇인가요?',148),('지금 몇시 인가요?',149),('요즘 주로 어떤 종류의 TV 프로그램을 시청하시나요?',150),('10년뒤에 어떤 모습이 되고 싶나요?',151),('가장 감사한 사람이 누구인가요?',152);
/*!40000 ALTER TABLE `fluency_problem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:08

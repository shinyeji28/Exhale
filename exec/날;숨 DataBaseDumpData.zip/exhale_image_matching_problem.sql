-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `image_matching_problem`
--

DROP TABLE IF EXISTS `image_matching_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image_matching_problem` (
  `answer` int DEFAULT NULL,
  `option_image1` varchar(255) DEFAULT NULL,
  `option_image2` varchar(255) DEFAULT NULL,
  `option_image3` varchar(255) DEFAULT NULL,
  `option_image4` varchar(255) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `problem_id` bigint NOT NULL,
  PRIMARY KEY (`problem_id`),
  CONSTRAINT `FKgtiwrhgc2l6whpxjhrfl95mj` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_matching_problem`
--

LOCK TABLES `image_matching_problem` WRITE;
/*!40000 ALTER TABLE `image_matching_problem` DISABLE KEYS */;
INSERT INTO `image_matching_problem` VALUES (3,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/puppy-1903313_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/kitten-4611189_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/animal-171318_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/animal-8169942_1920.jpg','아프리카에서 발견되는 포유류로, 목이 아주 길고 높은 나무의 잎을 먹는 동물은 무엇일까요?',127),(1,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/acorns-5646979_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/walnut-658569_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/peanut-390081_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/corn-3705687_1920.jpg','다람쥐의 주요 먹이로, 단단한 껍질과 부드러운 내부 구조를 가진 견과류는 무엇일까요?',128),(2,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/puppy-1903313_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/cheetah-2859581_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/kitten-4611189_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/animal-171318_1920.jpg','아프리카에서 발견되는 포유류로 시속 110~120km로 빠르게 달리는 육식 동물은 무엇일까요?',129),(1,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/usd-67411_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/cinnamon-rolls-1417494_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/pasta-3547078_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/soup-1787997_1920.jpg','아시아 지역에서 주요 식량으로 사용되는 곡물 중 하나로 우리나라도 이 음식을 주식으로 삼고 있습니다. 이 음식은 무엇일까요?',130),(3,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/baseball-1505036_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/fashion-1979136_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/traditional-775512_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/kimono-6608076_1920.jpg','우리나라의 전통 의상은 무엇일까요?',131),(4,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/mountains-482689_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/desert-1270345_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/beach-418742_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/amazon-4769367_1920.jpg','지구의 허파로 불리는 곳으로 지구에서 가장 큰 열대 우림 지대인 이곳은 어디일까요?',132),(2,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/polar-bear-404314_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/camel-4319_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/penguins-429134_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/puppy-1903313_1920.jpg','사막 근처에서 볼 수 있는 동물은 무엇일까요?',134),(3,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/cheetah-2859581_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/camel-4319_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/penguins-429134_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/puppy-1903313_1920.jpg','남극 주변에서 볼 수 있는 동물은 무엇일까요?',135),(1,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/metro-1853976_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/taxi-2729864_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/collective-435584_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/puppy-1903313_1920.jpg','지하 터널을 통해 운행되는 기차 형태의 대중 교통 수단은 무엇일까요?',136),(3,'https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/fiat-500-4322521_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/metro-1853976_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/cruise-1578528_1920.jpg','https://nalsum1.s3.ap-northeast-2.amazonaws.com/image_matching/aircraft-5611528_1920.jpg','바다를 건너는 대형 이동 수단은 무엇일까요?',137);
/*!40000 ALTER TABLE `image_matching_problem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:10

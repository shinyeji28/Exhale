-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i10b208.p.ssafy.io    Database: exhale
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `text_matching_problem`
--

DROP TABLE IF EXISTS `text_matching_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `text_matching_problem` (
  `answer` int DEFAULT NULL,
  `option1` varchar(255) DEFAULT NULL,
  `option2` varchar(255) DEFAULT NULL,
  `option3` varchar(255) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `question_image` varchar(255) DEFAULT NULL,
  `problem_id` bigint NOT NULL,
  PRIMARY KEY (`problem_id`),
  CONSTRAINT `FKheapgwefewyfi2y60wsoop6um` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_matching_problem`
--

LOCK TABLES `text_matching_problem` WRITE;
/*!40000 ALTER TABLE `text_matching_problem` DISABLE KEYS */;
INSERT INTO `text_matching_problem` VALUES (1,'미국','한국','캐나다','다음 사진의 나라는 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/american-flag.png',81),(2,'바나나','사과','수박','다음 사진의 과일 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/apple.jpg',82),(3,'도쿄','서울','파리','다음 사진의 도시 이름으 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/eiffel-tower.jpg',83),(1,'사자','고양이','강아지','다음 사진의 동물 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/lion.jpg',84),(1,'벚꽃','개나리꽃','민들레꽃','다음 사진의 식물 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/flowers.jpg',85),(3,'비가옴','맑음','눈내림','다음 사진의 날씨는 어떤 상태인가요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/winter-landscape.jpg',86),(2,'슬픔','행복','화남','다음 사진의 이모티콘은 어떤 감정을 나타내고 있을까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/smiley.jpg',87),(3,'화장실','부엌','거실','다음 사진의 가구는 어느 방에 가장 어울릴까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/leather-sofa.jpg',88),(2,'미켈란젤로','레오나르도 다 빈치','김홍도','다음 사진의 미술작품 작가는 누구일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/mona-lisa.jpg',89),(3,'바이올린','드럼','기타','다음 사진의 악기 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/guitar.jpg',90),(1,'축구','배구','야구','다음 사진의 스포츠 경기는 어떤 종목인가요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/soccer.jpg',91),(2,'왕좌의게임','해리포터','어벤져스','다음 사진의 책 제목은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/harrypotter.jpg',92),(1,'수박','멜론','참외','다음 사진의 과일 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/watermelon.jpg',93),(3,'참새','여우','토끼','다음 사진의 동물 이름은 무엇일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/bunny.jpg',94),(2,'흰색','빨간색','파란색','다음 사진의 자동차 색깔은 무슨 색일까요?','https://nalsum1.s3.ap-northeast-2.amazonaws.com/text-matching/fiat.jpg',95);
/*!40000 ALTER TABLE `text_matching_problem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  2:53:09
